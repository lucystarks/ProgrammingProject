#include <iostream>
#include <sstream>
#include <stdio.h>
using namespace std;

void startScreen() {
cout << "█▀▄▀█ █▀▀█ █▀▀▄ 　 █░░ ░▀░ █▀▀▄ █▀▀" << endl; 
cout << "█░▀░█ █▄▄█ █░░█ 　 █░░ ▀█▀ █▀▀▄ ▀▀█" << endl; 
cout << "▀░░░▀ ▀░░▀ ▀▀▀░ 　 ▀▀▀ ▀▀▀ ▀▀▀░ ▀▀▀" << endl;
  cout << "Welcome to MAD LIBS, by Lucy Starks. Press the spacebar for instructions. \n";  
}  

void closeScreen() {
cout << "████████╗██╗░░██╗███████╗  ███████╗███╗░░██╗██████╗░" << endl; 
cout << "╚══██╔══╝██║░░██║██╔════╝  ██╔════╝████╗░██║██╔══██╗" << endl;
cout << "░░░██║░░░███████║█████╗░░  █████╗░░██╔██╗██║██║░░██║" << endl;
cout << "░░░██║░░░██╔══██║██╔══╝░░  ██╔══╝░░██║╚████║██║░░██║" << endl;
cout << "░░░██║░░░██║░░██║███████╗  ███████╗██║░╚███║██████╔╝" << endl;
cout << "░░░╚═╝░░░╚═╝░░╚═╝╚══════╝  ╚══════╝╚═╝░░╚══╝╚═════╝░" << endl;
cout << "thanks for playing!!";
}

class Story1{
public:
char Pnoun[30];
char Noun[30];
char Adj[30];
char Sport[30];
char smove[30];
char ving[30];
char verb[30];
char verb2[30];

void get_words(void)
{
cout << "Enter a Proper Noun:" << endl;
  cin >> Pnoun;
cout << "Enter a Noun:" << endl;
  cin >> Noun;
cout << "Enter a Adjective:" << endl;
  cin >> Adj;
cout << "Enter a Sport:" << endl;
  cin >> Sport;
cout << "Enter maneuver from your chosen sport:" << endl;
  cin >> smove;
cout << "Enter a verb ending in -ing:" << endl;
  cin >> ving;
cout << "Enter a verb:" << endl;
  cin >> verb;
cout << "Enter a verb:" << endl;
  cin >> verb2;

}
void display_words(void);
};

void Story1::display_words(void) {
  cout << "There was once an adventurer named " << Pnoun << " who sought the journey of a lifetime." << "So they set out in search of a/an " << Noun << ". Early on, they encountered a very " << Adj << " creature. It stood in front of the path and said: “To pass, you must defeat me in " << Sport << ". Up to the challenge, you took them on. You took the first " << smove << ", hitting the creature square in the nose. Too easy. " << ving << ", you turned around to continue the journey. Unbeknownst to you, the creature " << verb << "up, and was rapidly approaching. Before you knew it, they socked you and you " << verb << " to the ground. Better luck next time I guess." << endl;
}

class Story2{
public:
char adj[30];
char adj2[30];
char adj3[30];
char music[30];
char meal[30];
char tv[30];
char adv[30];
char emo[30];
char adv2[30];

void get_words(void)
{
  cout << "Enter an Adjective:" << endl;
  cin >> adj;
  cout << "Enter another Adjective:" << endl;
  cin >> adj2;
  cout << "Enter your favorite music genre:" << endl;
  cin >> music;
  cout << "Enter your favorite hot meal:" << endl;
  cin >> meal;
  cout << "Enter a tv series you are watching:" << endl;
  cin >> tv;
  cout << "Enter an Adverb:" << endl;
  cin >> adv;
  cout << "Enter an emotion:" << endl;
  cin >> emo;
  cout << "Enter a different adverb:" << endl;
  cin >> adv2;
  cout << "Enter one more adjective:" << endl;
  cin >> adj3;
}
void display_words(void);
};

void Story2::display_words(void) {
  cout << "You open the door to your apartment and are greeted with a/an " << adj << " atmosphere. Shaking off any " << adj2 << " feeling, you head to the kitchen and begin to put the groceries away. Moving later into the night, Alexa has your favorite music on, " << music << ", and you wrap up your last assignment just as your favorite song comes on. The work was light, any other tasks were done, and some delicious " << meal << " were/was cooking.  What could go wrong? You settle down and reach for the remote, and just as you are about to turn on " << tv << ", it hits you: you left the batteries you had just picked up for the remote in the car. Of course. You grab your jacket and car keys on your way out. Once in the parking garage, you " << adv << " grab the batteries and hop in the elevator back up to your apartment. Ok, now you can relax. Turning the corner and counting the doors as you go.. 183, 184, 185..186? To your " << emo << ", the door was cracked open. That’s" << adj3 << ", you think, I’m sure it was closed when I left. “Hello?” you called as you creeped in. Everything looked the same, but something felt different and you couldn’t put your finger on it. Down the hall, your bathroom door creaks open." << adv2 << ", you approach, mentally preparing yourself for whatever you’ll find.";
}

class Story3{
public:
char bagel[30];
char adj[30];
char obs[30];
char curse[30];
char verb[30];
char ving[30];
char celeb[30];
char part[30];
char adj2[30];
char furn[30];
char room[30];

void get_words(void){
  cout << "Enter a bagel flavor" << endl;
  cin >> bagel;
  cout << "Enter an adjective:" << endl;
  cin >> adj;
  cout << "Enter an obstacle:" << endl;
  cin >> obs;
  cout << "Enter a curse word:" << endl;
  cin >> curse;
  cout << "Enter a verb:" << endl;
  cin >> verb;
  cout << "Enter a verb that ends with -ing:" << endl;
  cin >> ving;
  cout << "Enter a celebrity/public figure:" << endl;
  cin >> celeb;
  cout << "Enter a body part:" << endl;
  cin >> part;
  cout << "Enter a piece of furniture:" << endl;
  cin >> furn;
  cout << "Enter a Adjective:" << endl;
  cin >> adj2;
  cout << "Enter a room of the house:" << endl;
  cin >> room;
}
void display_words(void);
};

void Story3::display_words(void){
cout << "You walked down the road munching on your " << bagel << " bagel. A/an " << adj << "way to start this chilly winter morning. All of a sudden, you trip on a/an " << obs << " and hit the ground. Ouch. Your bagel escapes your grip and, strangely, rolls down the alley." << curse << "! You shout as you pick yourself up and " << verb << " after the abnormally fast rolling bagel. You're not focusing on your surroundings because you're determined to get your bagel back. Inevitably, you run into a wall and black out. . .Someone is " << ving << " you awake. You open your eyes--could it be? "<< celeb << "?  you should in disbelief. In their " << part << ", you spot your bagel. They take a bite, give it to you, and vanish. Before you can process the " << adj2 << " happenings, you wake up on the " << furn << " in your " << room << ". What a strange dream. " << endl;
}

int main() { 
startScreen(); 
  char s;
  cout << "Type in a word of choice that follows the indicated part of speech. Your decisions will affect the course of the story, so choose wisely. Press spacebar to continue, press 0 to quit. \n";
  cin.get(s);
if(s == ' ') { 
  int choice;
  cout << "Type the number corresponding with the story to continue, press 0 to quit:" << endl;
  cout << "Story 1" << endl;
  cout << "Story 2" << endl;
  cout << "Story 3" << endl;
  cin >> choice;
  
  if(choice == 1) {
    Story1 x;
    x.get_words();
    x.display_words();
    return 0;
  } else if(choice == 2) {
    Story2 y;
    y.get_words();
    y.display_words();
    return 0;
  } else if(choice == 3) {
    Story3 z;
    z.get_words();
    z.display_words();
    return 0;
  } else if(choice == 0) {
    closeScreen();
  }

} else if(s == 0)
  closeScreen();
}