#include <iostream>
using namespace std;

class partsOfSpeech {
  string n, a, v, pn, av;
}