#include <sstream>

using namespace std;

class Story{
public:
  double Pnoun;
  double Noun;
  double Verb;
  double Adj;
  double Adv;

  double getStory(void);
  void setPnoun(double pn);
  void setNoun(double n);
  void setVerb(double n);
  void setAdj(double n);
  void setAdv(double n);
};




